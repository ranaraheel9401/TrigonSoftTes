package com.digicon.testtrigonsoft.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.digicon.testtrigonsoft.R;
import com.digicon.testtrigonsoft.databinding.ListAllItemsBinding;
import com.digicon.testtrigonsoft.model.AllItem;
import com.digicon.testtrigonsoft.viewHolder.VHAllItems;

import java.util.List;

public class AdapterAllItems extends RecyclerView.Adapter<VHAllItems> {

    Context ctx;
    List<AllItem> arrayList;

    public AdapterAllItems(Context ctx, List<AllItem> arrayList) {
        this.ctx = ctx;
        this.arrayList = arrayList;
    }

    @NonNull
    @Override
    public VHAllItems onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ListAllItemsBinding binding;
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        binding = DataBindingUtil.inflate(layoutInflater, R.layout.list_all_items, parent, false);
        return new VHAllItems(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull VHAllItems holder, int position) {

        holder.onBind(arrayList.get(position));
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

}
