package com.digicon.testtrigonsoft.network;

import com.digicon.testtrigonsoft.model.MainModel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;

public interface ApiInterface {

    @GET("repositories?q=language=+sort:stars")
    Call<MainModel> getItems();

}
