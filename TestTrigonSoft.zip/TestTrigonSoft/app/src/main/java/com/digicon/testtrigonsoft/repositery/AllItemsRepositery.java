package com.digicon.testtrigonsoft.repositery;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.digicon.testtrigonsoft.model.MainModel;
import com.digicon.testtrigonsoft.network.ApiClient;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AllItemsRepositery {

    MutableLiveData<MainModel> mutableLiveData;
    ApiClient apiClient;
    Context mContext;

    public AllItemsRepositery() {
        this.mutableLiveData = new MutableLiveData<>();
    }

    public void getAllItems() {

        apiClient = ApiClient.getInstance(mContext);


        apiClient.getDashBoard(new Callback<MainModel>() {
            @Override
            public void onResponse(@NotNull Call<MainModel> call, @NotNull Response<MainModel> response) {
                mutableLiveData.postValue(response.body());
                Log.d("TAG3", "onResponse: " + response.body());
            }

            @Override
            public void onFailure(@NotNull Call<MainModel> call, @NotNull Throwable t) {
                mutableLiveData.postValue(null);
                Log.d("TAG33", "onResponse: " + t.getMessage());
            }
        });


    }

    public LiveData<MainModel> getSendItems() {
        getAllItems();
        return mutableLiveData;
    }
}
