package com.digicon.testtrigonsoft.network;

public class ApiUri {
    public static String BASE_URL = "https://api.github.com/search/";
}
