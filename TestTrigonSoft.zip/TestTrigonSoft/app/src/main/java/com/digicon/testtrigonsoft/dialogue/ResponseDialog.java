package com.digicon.testtrigonsoft.dialogue;


import android.annotation.SuppressLint;
import android.content.Context;

public class ResponseDialog {

    //    TODO: Constants
    public static final int NOTIFICATION_DURATION = 2000;

    @SuppressLint("StaticFieldLeak")
    private static Context context;
    private static android.app.ProgressDialog progressDialog;

    //        TODO: Initialize Progress Dialog
    public static void getInstance(Context ctx) {
        context = ctx;
        progressDialog = new android.app.ProgressDialog(context);
    }


    //    TODO: Show Progress Dialog
    public static void showProgressDialog(Context ctx, int title, int msg) {

        ResponseDialog.getInstance(ctx);

        progressDialog.setTitle(context.getString(title));
        progressDialog.setMessage(context.getString(msg));
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
    }


    //        TODO: Dismiss Progress Dialog
    public static void dismissProgressDialog() {
        progressDialog.dismiss();
    }

}


