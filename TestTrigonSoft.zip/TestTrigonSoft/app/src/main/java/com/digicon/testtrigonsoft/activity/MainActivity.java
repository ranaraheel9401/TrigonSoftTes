package com.digicon.testtrigonsoft.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.digicon.testtrigonsoft.R;
import com.digicon.testtrigonsoft.adapter.AdapterAllItems;
import com.digicon.testtrigonsoft.databinding.ActivityMainBinding;
import com.digicon.testtrigonsoft.dialogue.ResponseDialog;
import com.digicon.testtrigonsoft.model.AllItem;
import com.digicon.testtrigonsoft.model.MainModel;
import com.digicon.testtrigonsoft.viewModel.ViewModelAllItems;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    ViewModelAllItems viewModelAllItems;
    AppCompatActivity mContext;
    AdapterAllItems adapterAllItems;
    List<AllItem> modelList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mContext = this;
        binding = DataBindingUtil.setContentView(mContext, R.layout.activity_main);
        binding.recyclerItems.setLayoutManager(new LinearLayoutManager(mContext, RecyclerView.VERTICAL, false));
        setVM();
    }

    private void setVM() {
        viewModelAllItems = new ViewModelAllItems(mContext.getApplication());
        ResponseDialog.showProgressDialog(mContext, R.string.load_data, R.string.plz_w8t);
        setObserver();
    }

    public void setObserver() {

        viewModelAllItems = new ViewModelProvider(mContext).get(ViewModelAllItems.class);

        viewModelAllItems.getAllItems().observe(mContext, new Observer<MainModel>() {
            @Override
            public void onChanged(MainModel mainModel) {

                if (mainModel != null) {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            ResponseDialog.dismissProgressDialog();
                            setData(mainModel);
                        }
                    }, 2000);
                } else {
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            ResponseDialog.dismissProgressDialog();
                            Toast.makeText(mContext, "something went wrong", Toast.LENGTH_LONG).show();
                        }
                    }, 2000);
                }
            }
        });

    }

    @SuppressLint("SetTextI18n")
    private void setData(MainModel mainModel) {
        modelList = new ArrayList<>();
        modelList.addAll(mainModel.getItems());
        binding.totalCount.setText("total count: " + mainModel.getTotalCount() + " \n " +
                "Incomplete Results: " + mainModel.getIncompleteResults());
        setAllItemsAdapter(modelList);
    }

    private void setAllItemsAdapter(List<AllItem> modelList) {
        adapterAllItems = new AdapterAllItems(mContext, modelList);
        binding.recyclerItems.setAdapter(adapterAllItems);
    }

}