package com.digicon.testtrigonsoft.network;

import android.annotation.SuppressLint;
import android.content.Context;

import com.digicon.testtrigonsoft.model.MainModel;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import hu.akarnokd.rxjava3.retrofit.RxJava3CallAdapterFactory;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Header;

public class ApiClient {

    Context mContext;
    private ApiInterface apiInterface;

    @SuppressLint("StaticFieldLeak")
    private static ApiClient apiClient;

    private ApiClient(Context context) {
        this.mContext = context;

        Retrofit retrofit = new Retrofit.Builder().baseUrl(ApiUri.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJava3CallAdapterFactory.create())
                .client(getClient())
                .build();


        this.apiInterface = retrofit.create(ApiInterface.class);
    }

    public static ApiClient getInstance(Context mContext) {

               if (apiClient == null) {
            setInstance(new ApiClient(mContext));
        }
        return apiClient;
    }

    private static void setInstance(ApiClient apiClient) {
        ApiClient.apiClient = apiClient;
    }

    private OkHttpClient getClient() {
        return new OkHttpClient.Builder()
                .addInterceptor(new Interceptor() {
                    @NotNull
                    @Override
                    public Response intercept(@NotNull Chain chain) throws IOException {

                        Request.Builder builder = chain.request().newBuilder();
                        builder.addHeader("Accept", "application/json");
                        builder.addHeader("Content-Type", "application/json");

                        return chain.proceed(builder.build());
                    }
                })
                .addInterceptor(new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                .connectTimeout(1, TimeUnit.MINUTES)
                .readTimeout(1, TimeUnit.MINUTES)
                .writeTimeout(1, TimeUnit.MINUTES)
                .build();
    }

    public void getDashBoard(Callback<MainModel> callback) {
        Call<MainModel> call;
        call = this.apiInterface.getItems();
        call.enqueue(callback);
    }

}
