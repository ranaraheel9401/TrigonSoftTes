package com.digicon.testtrigonsoft.viewHolder;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.digicon.testtrigonsoft.databinding.ListAllItemsBinding;
import com.digicon.testtrigonsoft.model.AllItem;

public class VHAllItems extends RecyclerView.ViewHolder {

    ListAllItemsBinding binding;

    public VHAllItems(@NonNull ListAllItemsBinding listItemAddTeamBinding) {
        super(listItemAddTeamBinding.getRoot());
        this.binding = listItemAddTeamBinding;
    }

    @SuppressLint("SetTextI18n")
    public void onBind(AllItem listTeamMembers) {
        try {
            binding.textAllItems.setText("Id: " + listTeamMembers.getId() + "\n" +
                    "Forks: " + listTeamMembers.getForks() + "\n" +
                    "Fork: " + listTeamMembers.getFork() + "\n" +
                    "ArchiveUrl: " + listTeamMembers.getArchiveUrl() + "\n" +
                    "AssigneesUrl: " + listTeamMembers.getAssigneesUrl() + "\n" +
                    "BlobsUrl: " + listTeamMembers.getBlobsUrl() + "\n" +
                    "BranchesUrl: " + listTeamMembers.getBranchesUrl() + "\n" +
                    "CreatedAt: " + listTeamMembers.getCreatedAt() + "\n" +
                    "CloneUrl: " + listTeamMembers.getCloneUrl() + "\n" +
                    "CollaboratorsUrl: " + listTeamMembers.getCollaboratorsUrl() + "\n" +
                    "CommentsUrl: " + listTeamMembers.getCommentsUrl() + "\n" +
                    "CommitsUrl: " + listTeamMembers.getCommitsUrl() + "\n" +
                    "CompareUrl: " + listTeamMembers.getCompareUrl() + "\n" +
                    "ContentsUrl: " + listTeamMembers.getContentsUrl() + "\n" +
                    "ContributorsUrl: " + listTeamMembers.getContributorsUrl() + "\n" +
                    "DefaultBranch: " + listTeamMembers.getDefaultBranch() + "\n" +
                    "DeploymentsUrl: " + listTeamMembers.getDeploymentsUrl() + "\n" +
                    "Description: " + listTeamMembers.getDescription() + "\n" +
                    "DownloadsUrl: " + listTeamMembers.getDownloadsUrl() + "\n" +
                    "EventsUrl: " + listTeamMembers.getEventsUrl() + "\n" +
                    "ForksUrl: " + listTeamMembers.getForksUrl() + "\n" +
                    "FullName: " + listTeamMembers.getFullName() + "\n" +
                    "GitCommitsUrl: " + listTeamMembers.getGitCommitsUrl() + "\n" +
                    "GitRefsUrl: " + listTeamMembers.getGitRefsUrl() + "\n" +
                    "GitTagsUrl: " + listTeamMembers.getGitTagsUrl() + "\n" +
                    "GitUrl: " + listTeamMembers.getGitUrl() + "\n" +
                    "Homepage: " + listTeamMembers.getHomepage() + "\n" +
                    "HooksUrl: " + listTeamMembers.getHooksUrl() + "\n" +
                    "HtmlUrl: " + listTeamMembers.getHtmlUrl() + "\n" +
                    "IssueCommentUrl: " + listTeamMembers.getIssueCommentUrl() + "\n" +
                    "IssueEventsUrl: " + listTeamMembers.getIssueEventsUrl() + "\n" +
                    "IssuesUrl: " + listTeamMembers.getIssuesUrl() + "\n" +
                    "KeysUrl: " + listTeamMembers.getKeysUrl() + "\n" +
                    "LabelsUrl: " + listTeamMembers.getLabelsUrl() + "\n" +
                    "Language: " + listTeamMembers.getLanguage() + "\n" +
                    "LanguagesUrl: " + listTeamMembers.getLanguagesUrl() + "\n" +
                    "MergesUrl: " + listTeamMembers.getMergesUrl() + "\n" +
                    "MilestonesUrl: " + listTeamMembers.getMilestonesUrl() + "\n" +
                    "Name: " + listTeamMembers.getName() + "\n" +
                    "NodeId: " + listTeamMembers.getNodeId() + "\n" +
                    "NotificationsUrl: " + listTeamMembers.getNotificationsUrl() + "\n" +
                    "PullsUrl: " + listTeamMembers.getPullsUrl() + "\n" +
                    "PushedAt: " + listTeamMembers.getPushedAt() + "\n" +
                    "ReleasesUrl: " + listTeamMembers.getReleasesUrl() + "\n" +
                    "SshUrl: " + listTeamMembers.getSshUrl() + "\n" +
                    "StargazersUrl: " + listTeamMembers.getStargazersUrl() + "\n" +
                    "StatusesUrl: " + listTeamMembers.getStatusesUrl() + "\n" +
                    "SubscribersUrl: " + listTeamMembers.getSubscribersUrl() + "\n" +
                    "SubscriptionUrl: " + listTeamMembers.getSubscriptionUrl() + "\n" +
                    "SvnUrl: " + listTeamMembers.getSvnUrl() + "\n" +
                    "TagsUrl: " + listTeamMembers.getTagsUrl() + "\n" +
                    "TeamsUrl: " + listTeamMembers.getTeamsUrl() + "\n" +
                    "TreesUrl: " + listTeamMembers.getTreesUrl() + "\n" +
                    "UpdatedAt: " + listTeamMembers.getUpdatedAt() + "\n" +
                    "Url: " + listTeamMembers.getUrl() + "\n" +
                    "IsTemplate: " + listTeamMembers.getIsTemplate() + "\n" +
                    "License Details: " + "\n" +
                    "LicenseKey: " + listTeamMembers.getLicense().getKey() + "\n" +
                    "LicenseName: " + listTeamMembers.getLicense().getName() + "\n" +
                    "LicenseNodeId: " + listTeamMembers.getLicense().getNodeId() + "\n" +
                    "LicenseSpdxId: " + listTeamMembers.getLicense().getSpdxId() + "\n" +
                    "LicenseUrl: " + listTeamMembers.getLicense().getUrl() + "\n" +
                    "MirrorUrl: " + listTeamMembers.getMirrorUrl() + "\n" +
                    "OpenIssues: " + listTeamMembers.getOpenIssues() + "\n" +
                    "OpenIssuesCount: " + listTeamMembers.getOpenIssuesCount() + "\n" +
                    "Owner Details:" + "\n" +
                    "OwnerId: " + listTeamMembers.getOwner().getId() + "\n" +
                    "OwnerAvatarUrl: " + listTeamMembers.getOwner().getAvatarUrl() + "\n" +
                    "OwnerEventsUrl: " + listTeamMembers.getOwner().getEventsUrl() + "\n" +
                    "OwnerFollowersUrl: " + listTeamMembers.getOwner().getFollowersUrl() + "\n" +
                    "OwnerFollowingUrl: " + listTeamMembers.getOwner().getFollowingUrl() + "\n" +
                    "OwnerGistsUrl: " + listTeamMembers.getOwner().getGistsUrl() + "\n" +
                    "OwnerGravatarId: " + listTeamMembers.getOwner().getGravatarId() + "\n" +
                    "OwnerHtmlUrl: " + listTeamMembers.getOwner().getHtmlUrl() + "\n" +
                    "OwnerLogin: " + listTeamMembers.getOwner().getLogin() + "\n" +
                    "OwnerNodeId: " + listTeamMembers.getOwner().getNodeId() + "\n" +
                    "OwnerOrganizationsUrl: " + listTeamMembers.getOwner().getOrganizationsUrl() + "\n" +
                    "OwnerReceivedEventsUrl: " + listTeamMembers.getOwner().getReceivedEventsUrl() + "\n" +
                    "OwnerReposUrl: " + listTeamMembers.getOwner().getReposUrl() + "\n" +
                    "OwnerStarredUrl: " + listTeamMembers.getOwner().getStarredUrl() + "\n" +
                    "OwnerSubscriptionsUrl: " + listTeamMembers.getOwner().getSubscriptionsUrl() + "\n" +
                    "OwnerType: " + listTeamMembers.getOwner().getType() + "\n" +
                    "OwnerUrl: " + listTeamMembers.getOwner().getUrl() + "\n" +
                    "OwnerSiteAdmin: " + listTeamMembers.getOwner().getSiteAdmin() + "\n" +
                    "Private: " + listTeamMembers.getPrivate() + "\n" +
                    "Score: " + listTeamMembers.getScore() + "\n" +
                    "Size: " + listTeamMembers.getSize() + "\n" +
                    "StargazersCount: " + listTeamMembers.getStargazersCount() + "\n" +
                    "Topics: " + listTeamMembers.getTopics() + "\n" +
                    "Watchers: " + listTeamMembers.getWatchers() + "\n" +
                    "WatchersCount: " + listTeamMembers.getWatchersCount());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
