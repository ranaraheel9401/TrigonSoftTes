package com.digicon.testtrigonsoft.viewModel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.digicon.testtrigonsoft.model.MainModel;
import com.digicon.testtrigonsoft.repositery.AllItemsRepositery;

public class ViewModelAllItems extends AndroidViewModel {

    AllItemsRepositery mainRepository;

    public ViewModelAllItems(@NonNull Application application) {
        super(application);
        mainRepository = new AllItemsRepositery();
    }

    public LiveData<MainModel> getAllItems() {

        return mainRepository.getSendItems();
    }

}